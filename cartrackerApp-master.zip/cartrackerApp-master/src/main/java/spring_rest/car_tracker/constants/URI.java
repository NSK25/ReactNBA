package spring_rest.car_tracker.constants;

public final class URI {
	
	public static final String VECHILES = "vechiles";
	public static final String ID = "{vin}";

}
